# AGNdisk_data_analysis
